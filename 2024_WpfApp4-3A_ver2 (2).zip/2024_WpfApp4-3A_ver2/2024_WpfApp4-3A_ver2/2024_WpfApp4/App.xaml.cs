﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace _2024_WpfApp4
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
